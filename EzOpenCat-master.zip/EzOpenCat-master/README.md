# Ez 3D Printed OpenCat
Admires the people's work of [Petoi Nybble](https://www.hackster.io/RzLi/petoi-nybble-944867) open source project, this is an attempt to do it in 3D printing and using inexpensive servos. The codes here are modification for [Ez 3D Printed OpenCat](https://www.thingiverse.com/thing:3384371). You can find the complete instructions to build it there.

### Required Supporting Libraries:

* https://github.com/SloCompTech/QList.git
* https://github.com/McNeight/MemoryFree.git
* https://github.com/jrowberg/i2cdevlib/tree/master/Arduino/I2Cdev
* https://github.com/jrowberg/i2cdevlib/tree/master/Arduino/MPU6050
